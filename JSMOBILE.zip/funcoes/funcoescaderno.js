function dados (nome, sobrenome){
  if (typeof nome === 'string' && typeof sobrenome === 'string'){
    const res = "olá" + nome + "seu sobrenome é" + sobrenome
  
    alert res
} else {
  alert ("Digite seu nome corretamente")
}
}
 //dados ("Manu", "michetti")
//dados (17,"michetti")

function dados (nome, altura){
  if (typeof nome === 'string' && typeof altura === 'number'){
    const res = "olá" + nome + "sua altura é" + altura
    alert ("o resultado foi:" + res)
  } else {
    alert ("Por favor insira um número válido")
  }
}

    