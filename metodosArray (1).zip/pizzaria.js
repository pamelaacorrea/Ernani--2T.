/**
 *1) Crie um algoritmo que faça o seguinte:
     a) pergunte o nome do cliente e armazene em uma variável
     b) cumprimente o cliente e pergunte qual pizza ele quer pedir
     c) enquanto ele não tiver feito 3 pedidos continue perguntando
     d) a cada pedido feito, adicione o sabor escolhido a um array
     e) ao final, informe ao cliente a quantidade de pizzas do pedido
     f) imprima quais pizzas foram pedidas
*/
let sabores = [] // CRIAR UM ARRAY VAZIO
let pedidos = 0

const cliente = prompt("Olá, qual é seu nome? ")
// CHECAR COM IF SE O NOME DO USUÁRIO EXISTE
if (cliente){

alert("Olá " + cliente +", seja bem vindo(a)!")

// LOOP DE REPETIÇÃO INFINO (QUE RODA EMQUANTO UMA CONDIÇÃO FOT VERDADEIRA)
while(pedidos <3) {
  let sabor = prompt("Qual sabor de pizza você deseja ")
  if (sabor) {
  sabores.push(sabor) // ENVIAR PARA NOSSA LISTA
  alert("Pedido recebido!")
  }
  pedidos = pedidos + 1 // ACÚMULO DE VALORES
}
// IMPRIMIR LISTA
alert("Pedido fechado com sucesso! Olhe o seu Log!")
console.log("------ 🍕 PIZZARIA KI-GOSTOSO 🍕------------")
console.log(sabores)
console.log("---------------------------------------")
}
